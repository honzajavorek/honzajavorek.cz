﻿Carrot (c) Jan Javorek, 2007 (http://www.javorek.net)



Co je Morse?
------------

Morse je jednoduchý třída v PHP5 na převod Morseovky na text a naopak. Pracuje jen s textem v UTF-8 (nebo ASCII).



Licence
-------

Carrot je svobodný program. Můžete ho zdarma stáhnout, libovolně upravovat
a používat ve svých aplikacích v souladu s podmínkami GNU General Public License v2.
Přečtěte si pozorně licenční podmínky v souboru license.txt.



-----
Chcete-li další informace, navštivte stránky autora:
http://www.javorek.net/
