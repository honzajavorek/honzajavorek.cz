<?php
/**
 * Morse code converter.
 *
 * Created 6.8.2007 13:35:05.
 *
 * @author    Jan (Honza) Javorek aka Littlemaple <honza@javorek.net>
 * @package   Morse
 * @copyright Copyright (c) 2007 Jan Javorek
 * @link      http://www.javorek.net/
 * @license   GNU GENERAL PUBLIC LICENSE version 2
 */

class Morse {

	protected $table = array(
		'a' => '.-',    'ch' => '----',   'b' => '-...',   'c' => '-.-.',   'd' => '-..',     'e' => '.',      'f' => '..-.',
		'g' => '--.',   'h'  => '....',   'i' => '..',     'j' => '.---',   'k' => '-.-',     'l' => '.-..',   'm' => '--',
		'n' => '-.',    'o'  => '---',    'p' => '.--.',   'q' => '--.-',   'r' => '.-.',     's' => '...',    't' => '-',
		'u' => '..-',   'v'  => '...-',   'w' => '.--',    'x' => '-..-',   'y' => '-.--',    'z' => '--..',   '0' => '-----',
		'1' => '.----', '2'  => '..---',  '3' => '...--',  '4' => '....-',  '5' => '.....',   '6' => '-....',  '7' => '--...',
		'8' => '---..', '9'  => '----.',  '.' => '.-.-.-', ',' => '--..--', '?' => '..--..',  "'" => '.----.', '!' => '-.-.--',
		'/' => '-..-.', '('  => '-.--.',  ')' => '-.--.-', '&' => '.-...',  ':' => '---...',  ';' => '-.-.-.', '=' => '-...-',
		'+' => '.-.-.', '-'  => '-....-', '_' => '..--.-', '"' => '.-..-.', '$' => '...-..-', '@' => '.--.-.'
	);

	function __construct() {
	}
	
	protected function utf2ascii($s) {
    	static $tbl = array("\xc3\xa1"=>"a","\xc3\xa4"=>"a","\xc4\x8d"=>"c","\xc4\x8f"=>"d","\xc3\xa9"=>"e","\xc4\x9b"=>"e","\xc3\xad"=>"i","\xc4\xbe"=>"l","\xc4\xba"=>"l","\xc5\x88"=>"n","\xc3\xb3"=>"o","\xc3\xb6"=>"o","\xc5\x91"=>"o","\xc3\xb4"=>"o","\xc5\x99"=>"r","\xc5\x95"=>"r","\xc5\xa1"=>"s","\xc5\xa5"=>"t","\xc3\xba"=>"u","\xc5\xaf"=>"u","\xc3\xbc"=>"u","\xc5\xb1"=>"u","\xc3\xbd"=>"y","\xc5\xbe"=>"z","\xc3\x81"=>"A","\xc3\x84"=>"A","\xc4\x8c"=>"C","\xc4\x8e"=>"D","\xc3\x89"=>"E","\xc4\x9a"=>"E","\xc3\x8d"=>"I","\xc4\xbd"=>"L","\xc4\xb9"=>"L","\xc5\x87"=>"N","\xc3\x93"=>"O","\xc3\x96"=>"O","\xc5\x90"=>"O","\xc3\x94"=>"O","\xc5\x98"=>"R","\xc5\x94"=>"R","\xc5\xa0"=>"S","\xc5\xa4"=>"T","\xc3\x9a"=>"U","\xc5\xae"=>"U","\xc3\x9c"=>"U","\xc5\xb0"=>"U","\xc3\x9d"=>"Y","\xc5\xbd"=>"Z");
    	return strtr($s, $tbl);
	}
	
	protected function textNormalize($string) {
		$patterns = array(
			"\n", "\r", "\t", ' ',
			'#', '%', '*', '<', '>', '[', ']', '\\', '^', '`', '{', '}', '|', '~', '„', '“', '‚', '‘', '»', '«', '…', '“', '”', '‘', '’'
		);
		$replacements = array(
			' ', ' ', ' ', ' ',
			'', '', '', '(', ')', '(', ')', '/', '', "'", '(', ')', '/', '-', '"', '"', '"', '"', '"', '"', '...', '"', '"', '"', '"'	
		);
		return str_replace($patterns, $replacements, $this->utf2ascii($string));
	}
	
	protected function textFormat($string) {
		$patterns = array(
			'~\\s(\\W\\s)~', '~(\\s){2,}~', '~"\\s([^"]+)\\s"~'
		);
		$replacements = array(
			'\\1', '\\1', '"\\1"'
		);
		
		return strtoupper(preg_replace($patterns, $replacements, $string));	
	}
	
	protected function textEncode($string) {
		$patterns = array(
			// cleaning
			'~\\|~', '~-~',
			// sentences
			'~\\s*\\.\\s*~', '~\\s*\\!\\s*~', '~\\s*\\?\\s*~',
			// words
			'~\\s*,\\s*~', '~\\s*:\\s*~', '~\\s*;\\s*~', '~\\s*\\(\\s*~', '~\\s*\\)\\s*~', '~\\s-\\s~', '~\\s~',
			// quotes
			'~\\s*"([^"]+)"\\s*~'
		);
		$replacements = array(
			// cleaning
			'', $this->table['-'],
			// sentences
			"|{$this->table['.']}|||", "|{$this->table['!']}|||", "|{$this->table['?']}|||",
			// words
			"|{$this->table[',']}||", "|{$this->table[':']}||", "|{$this->table[';']}||", "|{$this->table['(']}||", "|{$this->table[')']}||", "|{$this->table['-']}||", '|',
			// quotes
			$this->table['"'] . '||\\1' . $this->table['"'] . '||'
		);
		$string = preg_replace($patterns, $replacements, $string);

		// letters
		$patterns = $replacements = array();
		foreach ($this->table as $text => $morse) {
			if (!in_array($text, array('|', '.', '-'))) {
				$patterns[] = $text;
				$replacements[] = $morse . '|';
			}
		}
		
		return str_ireplace($patterns, $replacements, $string);
	}
	
	
	
	protected function morseNormalize($string) {
		$patterns = array(
			"\n", "\r", "\t", ' ', '·', '*', '.', '/', '\\', '|', '-', '–', '—', '_'
		);
		$replacements = array(
			'', '', '', '', '.', '.', '.', '|', '|', '|', '-', '-', '-', '-'
		);
		return str_replace($patterns, $replacements, $string);
	}
	
	protected function morseFormat($string) {
		$patterns = array(
			'~[^\\.\\|\\-]~', '~\\.~', '~-~', '~\\|\\|\\|~'
		);
		$replacements = array(
			'', '&middot;', '&ndash;', '||| '
		);
		return preg_replace($patterns, $replacements, $string);	
	}
	
//	protected function compareLenghts($a, $b) {
//		$a = strlen($a);
//		$b = strlen($b);
//		return strcmp($a, $b);
//	}
	
	protected function morseDecode($string) {
		$patterns = $replacements = array();
		$table = array_flip($this->table);
		//uksort($table, array($this, 'compareLenghts'));
		
		$string = explode('|', $string);
		$text = '';
		foreach ($string as $part) {
			if (empty($part)) {
				$text .= ' ';
			} else {
				$text .= $table[$part];
			}
		}
		
		return $text;
	}
	
	
	
	public function morse2text($morse) {
		return $this->textFormat($this->morseDecode($this->morseNormalize($morse)));
	}
	
	public function text2morse($text) {
		return $this->morseFormat($this->textEncode($this->textNormalize($text)));
	}
	
}
?>
