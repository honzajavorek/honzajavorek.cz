Morse (c) Jan Javorek, 2007 (http://www.javorek.net)



What is Morse?
--------------

Morse is a simple class in PHP5 to convert Morse code to text and back. Works only with text in UTF-8 (and/or ASCII).



License
-------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU GENERAL PUBLIC LICENSE version 2 as published by
the Free Software Foundation. See license.txt in this directory
for a copy of the license.



-----
For more information, visit the author's website:
http://www.javorek.net/
